import './App.css'
import FBClone from './FBClone';

const App = () => {

  return (
    <>
    <FBClone />
    </>
  )
}

export default App;
